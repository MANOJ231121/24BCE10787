package com.vechilemanage.project_parkingmanagement;

import com.vechilemanage.project_parkingmanagement.model.Driver;
import com.vechilemanage.project_parkingmanagement.model.Vehicle;
import com.vechilemanage.project_parkingmanagement.model.Ticket;
import com.vechilemanage.project_parkingmanagement.model.Payment;
import com.vechilemanage.project_parkingmanagement.repository.DriverRepository;
import com.vechilemanage.project_parkingmanagement.repository.VehicleRepository;
import com.vechilemanage.project_parkingmanagement.service.VehicleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ProjectParkingmanagementApplicationTests {

	@Autowired
	private VehicleService vehicleService;

	@Autowired
	private DriverRepository driverRepository;

	@Autowired
	private VehicleRepository vehicleRepository;

	@Autowired
	private ObjectMapper objectMapper;

	@BeforeEach
	void setUp() {
		driverRepository.deleteAll();
		vehicleRepository.deleteAll();
	}

	@Test
	void testManyToManyRelationship() throws Exception {
		// 1. Create and save Driver
		Driver driver = new Driver("D101", "Manoj Kumar", "DL-987654321");
		driverRepository.save(driver);

		// 2. Create and save Vehicle
		Vehicle vehicle = new Vehicle("HP01AB1234", "Manoj Kumar", "Car");
		vehicleRepository.save(vehicle);

		// 3. Link them
		Vehicle linkedVehicle = vehicleService.linkDriverToVehicle("HP01AB1234", "D101");
		assertNotNull(linkedVehicle);

		// 4. Retrieve driver and vehicle to verify links
		Vehicle fetchedVehicle = vehicleRepository.findById("HP01AB1234").orElse(null);
		assertNotNull(fetchedVehicle);
		
		// Attempt to serialize to JSON to check for 500 / circular reference or lazy load issues
		String jsonVehicle = objectMapper.writeValueAsString(fetchedVehicle);
		System.out.println("Serialized Vehicle: " + jsonVehicle);

		Driver fetchedDriver = driverRepository.findById("D101").orElse(null);
		assertNotNull(fetchedDriver);
		String jsonDriver = objectMapper.writeValueAsString(fetchedDriver);
		System.out.println("Serialized Driver: " + jsonDriver);
	}

	@Autowired
	private com.vechilemanage.project_parkingmanagement.service.TicketService ticketService;

	@Autowired
	private com.vechilemanage.project_parkingmanagement.repository.ParkingSlotRepository parkingSlotRepository;

	@Autowired
	private com.vechilemanage.project_parkingmanagement.repository.TicketRepository ticketRepository;

	@Autowired
	private com.vechilemanage.project_parkingmanagement.repository.PaymentRepository paymentRepository;

	@Test
	void testTicketEntryExitAndQueries() throws Exception {
		// 1. Setup parking slot
		parkingSlotRepository.deleteAll();
		ticketRepository.deleteAll();
		paymentRepository.deleteAll();

		com.vechilemanage.project_parkingmanagement.model.ParkingSlot slot = 
			new com.vechilemanage.project_parkingmanagement.model.ParkingSlot(1, "A-101", "Available");
		parkingSlotRepository.save(slot);

		// 2. Register Vehicle
		Vehicle vehicle = new Vehicle("HP01AB1234", "Manoj Kumar", "Car");
		vehicleRepository.save(vehicle);

		// 3. Generate Ticket (Entry)
		Ticket ticket = ticketService.generateTicket("HP01AB1234", 1);
		assertNotNull(ticket);
		assertEquals("Occupied", parkingSlotRepository.findById(1L).get().getStatus());

		// 4. Retrieve ticket by vehicle
		List<Ticket> ticketsByVehicle = ticketService.getTicketsByVehicle("HP01AB1234");
		assertFalse(ticketsByVehicle.isEmpty(), "Should find tickets for vehicle HP01AB1234");

		// 5. Record Exit
		Ticket exitTicket = ticketService.recordExit(ticket.getTicketId());
		assertNotNull(exitTicket);
		assertNotNull(exitTicket.getExitTime());
		assertEquals("Available", parkingSlotRepository.findById(1L).get().getStatus());

		// 6. Verify Payment is created and can be fetched by ticket ID
		Optional<Payment> payment = paymentRepository.findByTicketId(ticket.getTicketId());
		assertTrue(payment.isPresent(), "Payment should exist for ticket ID " + ticket.getTicketId());
		assertEquals("Pending", payment.get().getStatus());
	}
}
