package com.vechilemanage.project_parkingmanagement.service;

import com.vechilemanage.project_parkingmanagement.model.Payment;
import com.vechilemanage.project_parkingmanagement.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public Optional<Payment> getPaymentById(long paymentId) {
        return paymentRepository.findById(paymentId);
    }

    public List<Payment> getPendingPayments() {
        return paymentRepository.findByStatus("Pending");
    }

    public List<Payment> getPaidPayments() {
        return paymentRepository.findByStatus("Paid");
    }

    public Optional<Payment> getPaymentByTicketId(long ticketId) {
        return paymentRepository.findByTicketId(ticketId);
    }

    public Payment markPaymentAsPaid(long paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found with ID: " + paymentId));
        
        if ("Paid".equalsIgnoreCase(payment.getStatus())) {
            throw new IllegalStateException("Payment ID " + paymentId + " is already Paid.");
        }
        
        payment.setStatus("Paid");
        return paymentRepository.save(payment);
    }

    public void deletePayment(long paymentId) {
        if (!paymentRepository.existsById(paymentId)) {
            throw new IllegalArgumentException("Payment not found with ID: " + paymentId);
        }
        paymentRepository.deleteById(paymentId);
    }
}
