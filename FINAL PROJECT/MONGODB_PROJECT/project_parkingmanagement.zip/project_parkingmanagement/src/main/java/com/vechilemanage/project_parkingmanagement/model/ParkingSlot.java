package com.vechilemanage.project_parkingmanagement.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "parking_slots")
public class ParkingSlot {

    @Id
    private long slotId;
    private String slotNumber;
    private String status; // Available, Occupied

    public ParkingSlot() {}

    public ParkingSlot(long slotId, String slotNumber, String status) {
        this.slotId = slotId;
        this.slotNumber = slotNumber;
        this.status = status;
    }

    public long getSlotId() {
        return slotId;
    }

    public void setSlotId(long slotId) {
        this.slotId = slotId;
    }

    public String getSlotNumber() {
        return slotNumber;
    }

    public void setSlotNumber(String slotNumber) {
        this.slotNumber = slotNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
