package com.vechilemanage.project_parkingmanagement.service;

import com.vechilemanage.project_parkingmanagement.model.ParkingSlot;
import com.vechilemanage.project_parkingmanagement.repository.ParkingSlotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ParkingSlotService {

    private final ParkingSlotRepository parkingSlotRepository;
    private final SequenceGeneratorService sequenceGeneratorService;

    @Autowired
    public ParkingSlotService(ParkingSlotRepository parkingSlotRepository, SequenceGeneratorService sequenceGeneratorService) {
        this.parkingSlotRepository = parkingSlotRepository;
        this.sequenceGeneratorService = sequenceGeneratorService;
    }

    public List<ParkingSlot> getAllSlots() {
        return parkingSlotRepository.findAll();
    }

    public List<ParkingSlot> getAvailableSlots() {
        return parkingSlotRepository.findByStatus("Available");
    }

    public Optional<ParkingSlot> getSlotById(long slotId) {
        return parkingSlotRepository.findById(slotId);
    }

    public ParkingSlot addSlot(ParkingSlot slot) {
        // Find if slot number already exists
        if (parkingSlotRepository.findBySlotNumber(slot.getSlotNumber()).isPresent()) {
            throw new IllegalArgumentException("Slot number " + slot.getSlotNumber() + " already exists.");
        }
        
        // Auto-increment ID
        slot.setSlotId(sequenceGeneratorService.generateSequence("slots_sequence"));
        
        // Default to Available if not specified
        if (slot.getStatus() == null || slot.getStatus().trim().isEmpty()) {
            slot.setStatus("Available");
        }
        return parkingSlotRepository.save(slot);
    }

    public ParkingSlot updateSlotStatus(long slotId, String status) {
        ParkingSlot slot = parkingSlotRepository.findById(slotId)
                .orElseThrow(() -> new IllegalArgumentException("Slot not found with ID: " + slotId));
        
        if (!status.equalsIgnoreCase("Available") && !status.equalsIgnoreCase("Occupied")) {
            throw new IllegalArgumentException("Invalid status. Must be 'Available' or 'Occupied'.");
        }
        
        slot.setStatus(status);
        return parkingSlotRepository.save(slot);
    }

    public void deleteSlot(long slotId) {
        ParkingSlot slot = parkingSlotRepository.findById(slotId)
                .orElseThrow(() -> new IllegalArgumentException("Slot not found with ID: " + slotId));
        
        if ("Occupied".equalsIgnoreCase(slot.getStatus())) {
            throw new IllegalStateException("Cannot delete slot ID " + slotId + " as it is currently Occupied.");
        }
        
        parkingSlotRepository.delete(slot);
    }
}
