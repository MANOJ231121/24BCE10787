package com.vechilemanage.project_parkingmanagement.repository;

import com.vechilemanage.project_parkingmanagement.model.Driver;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DriverRepository extends MongoRepository<Driver, String> {
    Optional<Driver> findByLicenseNumber(String licenseNumber);
}
