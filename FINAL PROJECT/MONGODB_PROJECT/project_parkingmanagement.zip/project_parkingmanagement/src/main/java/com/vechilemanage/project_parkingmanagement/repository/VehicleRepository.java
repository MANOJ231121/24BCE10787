package com.vechilemanage.project_parkingmanagement.repository;

import com.vechilemanage.project_parkingmanagement.model.Vehicle;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VehicleRepository extends MongoRepository<Vehicle, String> {
    List<Vehicle> findByVehicleType(String vehicleType);
}
