package com.vechilemanage.project_parkingmanagement.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;

@Document(collection = "payments")
public class Payment {

    @Id
    private long paymentId;
    private double amount;
    private String status; // Pending, Paid

    @DocumentReference(lazy = true)
    private Ticket ticket;

    public Payment() {}

    public Payment(long paymentId, double amount, String status, Ticket ticket) {
        this.paymentId = paymentId;
        this.amount = amount;
        this.status = status;
        this.ticket = ticket;
    }

    public long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(long paymentId) {
        this.paymentId = paymentId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }
}
