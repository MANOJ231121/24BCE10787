package com.vechilemanage.project_parkingmanagement.service;

import com.vechilemanage.project_parkingmanagement.model.Driver;
import com.vechilemanage.project_parkingmanagement.model.Vehicle;
import com.vechilemanage.project_parkingmanagement.repository.DriverRepository;
import com.vechilemanage.project_parkingmanagement.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VehicleService {

    private final VehicleRepository vehicleRepository;
    private final DriverRepository driverRepository;

    @Autowired
    public VehicleService(VehicleRepository vehicleRepository, DriverRepository driverRepository) {
        this.vehicleRepository = vehicleRepository;
        this.driverRepository = driverRepository;
    }

    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    public Optional<Vehicle> getVehicleByNo(String vehicleNo) {
        return vehicleRepository.findById(vehicleNo);
    }

    public List<Vehicle> getVehiclesByType(String vehicleType) {
        return vehicleRepository.findByVehicleType(vehicleType);
    }

    public Vehicle registerVehicle(Vehicle vehicle) {
        if (vehicleRepository.existsById(vehicle.getVehicleNo())) {
            throw new IllegalArgumentException("Vehicle with number " + vehicle.getVehicleNo() + " is already registered.");
        }
        return vehicleRepository.save(vehicle);
    }

    public Vehicle updateVehicle(String vehicleNo, Vehicle vehicleDetails) {
        Vehicle vehicle = vehicleRepository.findById(vehicleNo)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found: " + vehicleNo));
        vehicle.setOwnerName(vehicleDetails.getOwnerName());
        vehicle.setVehicleType(vehicleDetails.getVehicleType());
        return vehicleRepository.save(vehicle);
    }

    public void deleteVehicle(String vehicleNo) {
        Vehicle vehicle = vehicleRepository.findById(vehicleNo)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found: " + vehicleNo));
        
        // Remove relationships from associated drivers
        if (vehicle.getDrivers() != null) {
            for (Driver driver : vehicle.getDrivers()) {
                Driver actualDriver = driverRepository.findById(driver.getDriverId()).orElse(null);
                if (actualDriver != null) {
                    actualDriver.removeVehicle(vehicle);
                    driverRepository.save(actualDriver);
                }
            }
        }
        vehicleRepository.delete(vehicle);
    }

    public Vehicle linkDriverToVehicle(String vehicleNo, String driverId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleNo)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found: " + vehicleNo));
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new IllegalArgumentException("Driver not found: " + driverId));

        vehicle.addDriver(driver);
        driver.addVehicle(vehicle);

        driverRepository.save(driver);
        return vehicleRepository.save(vehicle);
    }

    public Vehicle unlinkDriverFromVehicle(String vehicleNo, String driverId) {
        Vehicle vehicle = vehicleRepository.findById(vehicleNo)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found: " + vehicleNo));
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new IllegalArgumentException("Driver not found: " + driverId));

        vehicle.removeDriver(driver);
        driver.removeVehicle(vehicle);

        driverRepository.save(driver);
        return vehicleRepository.save(vehicle);
    }
}
