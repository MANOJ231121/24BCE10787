package com.vechilemanage.project_parkingmanagement.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Document(collection = "vehicles")
public class Vehicle {

    @Id
    private String vehicleNo;
    private String ownerName;
    private String vehicleType; // Bike, Car, Truck, Bus

    @ReadOnlyProperty
    @DocumentReference(lazy = true, lookup = "{ 'vehicles': ?#{#self} }")
    @JsonIgnoreProperties("vehicles")
    private List<Driver> drivers = new ArrayList<>();

    public Vehicle() {}

    public Vehicle(String vehicleNo, String ownerName, String vehicleType) {
        this.vehicleNo = vehicleNo;
        this.ownerName = ownerName;
        this.vehicleType = vehicleType;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public List<Driver> getDrivers() {
        return drivers;
    }

    public void setDrivers(List<Driver> drivers) {
        this.drivers = drivers;
    }

    public void addDriver(Driver driver) {
        if (this.drivers == null) {
            this.drivers = new ArrayList<>();
        }
        if (!this.drivers.contains(driver)) {
            this.drivers.add(driver);
        }
    }

    public void removeDriver(Driver driver) {
        if (this.drivers != null) {
            this.drivers.remove(driver);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vehicle vehicle = (Vehicle) o;
        return Objects.equals(vehicleNo, vehicle.vehicleNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(vehicleNo);
    }
}
