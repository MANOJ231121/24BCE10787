package com.vechilemanage.project_parkingmanagement.service;

import com.vechilemanage.project_parkingmanagement.model.Driver;
import com.vechilemanage.project_parkingmanagement.model.Vehicle;
import com.vechilemanage.project_parkingmanagement.repository.DriverRepository;
import com.vechilemanage.project_parkingmanagement.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DriverService {

    private final DriverRepository driverRepository;
    private final VehicleRepository vehicleRepository;

    @Autowired
    public DriverService(DriverRepository driverRepository, VehicleRepository vehicleRepository) {
        this.driverRepository = driverRepository;
        this.vehicleRepository = vehicleRepository;
    }

    public List<Driver> getAllDrivers() {
        return driverRepository.findAll();
    }

    public Optional<Driver> getDriverById(String driverId) {
        return driverRepository.findById(driverId);
    }

    public Driver createDriver(Driver driver) {
        if (driver.getDriverId() != null && driverRepository.existsById(driver.getDriverId())) {
            throw new IllegalArgumentException("Driver with ID " + driver.getDriverId() + " already exists.");
        }
        return driverRepository.save(driver);
    }

    public Driver updateDriver(String driverId, Driver driverDetails) {
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new IllegalArgumentException("Driver not found: " + driverId));
        driver.setName(driverDetails.getName());
        driver.setLicenseNumber(driverDetails.getLicenseNumber());
        return driverRepository.save(driver);
    }

    public void deleteDriver(String driverId) {
        Driver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new IllegalArgumentException("Driver not found: " + driverId));
        
        // Vehicle doesn't store driver references in MongoDB (drivers list is a lookup dynamic query on drivers collection).
        // Deleting the driver automatically cleans up the relationship.
        driverRepository.delete(driver);
    }
}
