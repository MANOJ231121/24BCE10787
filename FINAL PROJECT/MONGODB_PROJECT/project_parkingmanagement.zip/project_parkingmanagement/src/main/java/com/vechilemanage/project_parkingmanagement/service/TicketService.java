package com.vechilemanage.project_parkingmanagement.service;

import com.vechilemanage.project_parkingmanagement.model.ParkingSlot;
import com.vechilemanage.project_parkingmanagement.model.Payment;
import com.vechilemanage.project_parkingmanagement.model.Ticket;
import com.vechilemanage.project_parkingmanagement.model.Vehicle;
import com.vechilemanage.project_parkingmanagement.repository.ParkingSlotRepository;
import com.vechilemanage.project_parkingmanagement.repository.PaymentRepository;
import com.vechilemanage.project_parkingmanagement.repository.TicketRepository;
import com.vechilemanage.project_parkingmanagement.repository.VehicleRepository;
import com.vechilemanage.project_parkingmanagement.util.ParkingChargeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final VehicleRepository vehicleRepository;
    private final ParkingSlotRepository parkingSlotRepository;
    private final PaymentRepository paymentRepository;
    private final SequenceGeneratorService sequenceGeneratorService;

    @Autowired
    public TicketService(TicketRepository ticketRepository,
                         VehicleRepository vehicleRepository,
                         ParkingSlotRepository parkingSlotRepository,
                         PaymentRepository paymentRepository,
                         SequenceGeneratorService sequenceGeneratorService) {
        this.ticketRepository = ticketRepository;
        this.vehicleRepository = vehicleRepository;
        this.parkingSlotRepository = parkingSlotRepository;
        this.paymentRepository = paymentRepository;
        this.sequenceGeneratorService = sequenceGeneratorService;
    }

    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }

    public Optional<Ticket> getTicketById(long ticketId) {
        return ticketRepository.findById(ticketId);
    }

    public List<Ticket> getActiveTickets() {
        return ticketRepository.findByExitTimeIsNull();
    }

    public List<Ticket> getTicketsByVehicle(String vehicleNo) {
        return ticketRepository.findByVehicleId(vehicleNo);
    }

    public Ticket generateTicket(String vehicleNo, long slotId) {
        // 1. Verify vehicle is registered
        Vehicle vehicle = vehicleRepository.findById(vehicleNo)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle " + vehicleNo + " is not registered. Register the vehicle first."));

        // 2. Verify slot exists and is Available
        ParkingSlot slot = parkingSlotRepository.findById(slotId)
                .orElseThrow(() -> new IllegalArgumentException("Parking slot not found with ID: " + slotId));

        if (!"Available".equalsIgnoreCase(slot.getStatus())) {
            throw new IllegalStateException("Parking slot " + slot.getSlotNumber() + " is not available. Status: " + slot.getStatus());
        }

        // 3. Verify vehicle doesn't already have an active ticket
        List<Ticket> activeTickets = ticketRepository.findByExitTimeIsNull();
        boolean alreadyParked = activeTickets.stream()
                .anyMatch(t -> t.getVehicle() != null && vehicleNo.equalsIgnoreCase(t.getVehicle().getVehicleNo()));
        if (alreadyParked) {
            throw new IllegalStateException("Vehicle " + vehicleNo + " already has an active ticket and is currently parked.");
        }

        // 4. Generate new ticket
        long ticketId = sequenceGeneratorService.generateSequence("tickets_sequence");
        Ticket ticket = new Ticket(ticketId, LocalDateTime.now(), vehicle, slot);
        
        // 5. Update slot status to Occupied
        slot.setStatus("Occupied");
        parkingSlotRepository.save(slot);

        return ticketRepository.save(ticket);
    }

    public Ticket recordExit(long ticketId) {
        // 1. Fetch ticket
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found with ID: " + ticketId));

        if (ticket.getExitTime() != null) {
            throw new IllegalStateException("Exit time is already recorded for ticket ID " + ticketId);
        }

        // 2. Set exit time
        LocalDateTime exitTime = LocalDateTime.now();
        ticket.setExitTime(exitTime);

        // 3. Free up the slot
        ParkingSlot slot = ticket.getParkingSlot();
        if (slot != null) {
            ParkingSlot actualSlot = parkingSlotRepository.findById(slot.getSlotId())
                    .orElseThrow(() -> new IllegalArgumentException("Parking slot not found: " + slot.getSlotId()));
            actualSlot.setStatus("Available");
            parkingSlotRepository.save(actualSlot);
        }

        // 4. Calculate charges
        String vehicleType = ticket.getVehicle() != null ? ticket.getVehicle().getVehicleType() : "Car";
        double amount = ParkingChargeUtil.calculateChargeFromTimes(vehicleType, ticket.getEntryTime(), exitTime);

        // 5. Generate a payment bill automatically
        long paymentId = sequenceGeneratorService.generateSequence("payments_sequence");
        Payment payment = new Payment(paymentId, amount, "Pending", ticket);
        paymentRepository.save(payment);

        return ticketRepository.save(ticket);
    }

    public void deleteTicket(long ticketId) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found with ID: " + ticketId));
        
        // Guard: If ticket is still active, free slot first
        if (ticket.getExitTime() == null && ticket.getParkingSlot() != null) {
            ParkingSlot slot = ticket.getParkingSlot();
            ParkingSlot actualSlot = parkingSlotRepository.findById(slot.getSlotId())
                    .orElseThrow(() -> new IllegalArgumentException("Parking slot not found: " + slot.getSlotId()));
            actualSlot.setStatus("Available");
            parkingSlotRepository.save(actualSlot);
        }

        // If there's an associated payment, delete it as well
        paymentRepository.findByTicketId(ticketId).ifPresent(paymentRepository::delete);

        ticketRepository.delete(ticket);
    }
}
