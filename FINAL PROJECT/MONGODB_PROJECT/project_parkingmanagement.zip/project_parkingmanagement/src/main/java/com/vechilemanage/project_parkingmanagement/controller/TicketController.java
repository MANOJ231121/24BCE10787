package com.vechilemanage.project_parkingmanagement.controller;

import com.vechilemanage.project_parkingmanagement.model.Ticket;
import com.vechilemanage.project_parkingmanagement.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService ticketService;

    @Autowired
    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @GetMapping
    public ResponseEntity<List<Ticket>> getAllTickets() {
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @GetMapping("/active")
    public ResponseEntity<List<Ticket>> getActiveTickets() {
        return ResponseEntity.ok(ticketService.getActiveTickets());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Ticket> getTicketById(@PathVariable long id) {
        return ticketService.getTicketById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/vehicle/{vehicleNo}")
    public ResponseEntity<List<Ticket>> getTicketsByVehicle(@PathVariable String vehicleNo) {
        return ResponseEntity.ok(ticketService.getTicketsByVehicle(vehicleNo));
    }

    @PostMapping("/entry")
    public ResponseEntity<?> generateTicket(@RequestParam String vehicleNo, @RequestParam long slotId) {
        try {
            Ticket ticket = ticketService.generateTicket(vehicleNo, slotId);
            return ResponseEntity.status(HttpStatus.CREATED).body(ticket);
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{id}/exit")
    public ResponseEntity<?> recordExit(@PathVariable long id) {
        try {
            Ticket ticket = ticketService.recordExit(id);
            return ResponseEntity.ok(ticket);
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTicket(@PathVariable long id) {
        try {
            ticketService.deleteTicket(id);
            return ResponseEntity.ok("Ticket with ID " + id + " (and any associated payments) was successfully deleted.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
