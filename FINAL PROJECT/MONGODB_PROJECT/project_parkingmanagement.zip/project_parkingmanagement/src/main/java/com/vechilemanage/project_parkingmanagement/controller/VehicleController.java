package com.vechilemanage.project_parkingmanagement.controller;

import com.vechilemanage.project_parkingmanagement.model.Vehicle;
import com.vechilemanage.project_parkingmanagement.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    private final VehicleService vehicleService;

    @Autowired
    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @GetMapping
    public ResponseEntity<List<Vehicle>> getAllVehicles() {
        return ResponseEntity.ok(vehicleService.getAllVehicles());
    }

    @GetMapping("/{vehicleNo}")
    public ResponseEntity<Vehicle> getVehicleByNo(@PathVariable String vehicleNo) {
        return vehicleService.getVehicleByNo(vehicleNo)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/type/{vehicleType}")
    public ResponseEntity<List<Vehicle>> getVehiclesByType(@PathVariable String vehicleType) {
        return ResponseEntity.ok(vehicleService.getVehiclesByType(vehicleType));
    }

    @PostMapping
    public ResponseEntity<?> registerVehicle(@RequestBody Vehicle vehicle) {
        try {
            Vehicle created = vehicleService.registerVehicle(vehicle);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{vehicleNo}")
    public ResponseEntity<?> updateVehicle(@PathVariable String vehicleNo, @RequestBody Vehicle vehicleDetails) {
        try {
            Vehicle updated = vehicleService.updateVehicle(vehicleNo, vehicleDetails);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{vehicleNo}")
    public ResponseEntity<?> deleteVehicle(@PathVariable String vehicleNo) {
        try {
            vehicleService.deleteVehicle(vehicleNo);
            return ResponseEntity.ok("Vehicle with number " + vehicleNo + " was successfully deleted.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{vehicleNo}/link-driver/{driverId}")
    public ResponseEntity<?> linkDriverToVehicle(@PathVariable String vehicleNo, @PathVariable String driverId) {
        try {
            Vehicle updatedVehicle = vehicleService.linkDriverToVehicle(vehicleNo, driverId);
            return ResponseEntity.ok(updatedVehicle);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{vehicleNo}/unlink-driver/{driverId}")
    public ResponseEntity<?> unlinkDriverFromVehicle(@PathVariable String vehicleNo, @PathVariable String driverId) {
        try {
            Vehicle updatedVehicle = vehicleService.unlinkDriverFromVehicle(vehicleNo, driverId);
            return ResponseEntity.ok(updatedVehicle);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
