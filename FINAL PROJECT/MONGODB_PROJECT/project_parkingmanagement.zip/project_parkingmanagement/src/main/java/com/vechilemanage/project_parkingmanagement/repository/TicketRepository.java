package com.vechilemanage.project_parkingmanagement.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.vechilemanage.project_parkingmanagement.model.Ticket;

@Repository
public interface TicketRepository extends MongoRepository<Ticket, Long> {
    
    List<Ticket> findByExitTimeIsNull();
    
   @Query("{ 'vehicle': ?0 }")
   List<Ticket> findByVehicleId(String vehicleNo);
}
