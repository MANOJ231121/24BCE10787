package com.vechilemanage.project_parkingmanagement.repository;

import com.vechilemanage.project_parkingmanagement.model.ParkingSlot;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ParkingSlotRepository extends MongoRepository<ParkingSlot, Long> {
    List<ParkingSlot> findByStatus(String status);
    Optional<ParkingSlot> findBySlotNumber(String slotNumber);
}
