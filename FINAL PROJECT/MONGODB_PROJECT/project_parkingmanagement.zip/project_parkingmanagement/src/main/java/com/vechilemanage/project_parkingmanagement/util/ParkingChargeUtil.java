package com.vechilemanage.project_parkingmanagement.util;

import java.time.LocalDateTime;
import java.time.Duration;

/**
 * Utility class for calculating parking charges.
 * Rate Card (per hour):
 *   Bike  – ₹ 10 / hr
 *   Car   – ₹ 20 / hr
 *   Truck – ₹ 40 / hr
 *   Bus   – ₹ 50 / hr
 * Minimum charge = 1 hour.
 * Partial hours are rounded UP.
 */
public class ParkingChargeUtil {

    private static final double BIKE_RATE  = 10.0;
    private static final double CAR_RATE   = 20.0;
    private static final double TRUCK_RATE = 40.0;
    private static final double BUS_RATE   = 50.0;

    private ParkingChargeUtil() {}

    public static double getRatePerHour(String vehicleType) {
        if (vehicleType == null) return CAR_RATE;
        return switch (vehicleType.trim().toLowerCase()) {
            case "bike"  -> BIKE_RATE;
            case "car"   -> CAR_RATE;
            case "truck" -> TRUCK_RATE;
            case "bus"   -> BUS_RATE;
            default      -> CAR_RATE;
        };
    }

    public static double calculateCharge(String vehicleType, double hours) {
        if (hours <= 0) hours = 1.0;
        long billedHours = (long) Math.ceil(hours);
        double rate = getRatePerHour(vehicleType);
        return rate * billedHours;
    }

    public static double calculateDurationHours(LocalDateTime entry, LocalDateTime exit) {
        if (entry == null || exit == null) return 1.0;
        long minutes = Duration.between(entry, exit).toMinutes();
        if (minutes < 0) minutes = 60; // default 1 hour if exit is before entry
        return minutes / 60.0;
    }

    public static double calculateChargeFromTimes(String vehicleType, LocalDateTime entry, LocalDateTime exit) {
        double hours = calculateDurationHours(entry, exit);
        return calculateCharge(vehicleType, hours);
    }
}
