package com.vechilemanage.project_parkingmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectParkingmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectParkingmanagementApplication.class, args);
	}

}
