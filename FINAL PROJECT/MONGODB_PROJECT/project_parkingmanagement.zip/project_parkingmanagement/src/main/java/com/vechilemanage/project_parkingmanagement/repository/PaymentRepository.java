package com.vechilemanage.project_parkingmanagement.repository;

import com.vechilemanage.project_parkingmanagement.model.Payment;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends MongoRepository<Payment, Long> {
    
    List<Payment> findByStatus(String status);
    
    @Query("{ 'ticket': ?0 }")
    Optional<Payment> findByTicketId(long ticketId);
}
